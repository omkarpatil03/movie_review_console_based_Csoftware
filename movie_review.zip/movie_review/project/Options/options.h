#ifndef options_H_
#define options_H_

#include <stdint.h>

void Options(int *);

#endif