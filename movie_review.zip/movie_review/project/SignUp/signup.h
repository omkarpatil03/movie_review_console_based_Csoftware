#ifndef signup_H_
#define signup_H_

#include "../StructureResources.h"

void SignUpPage(userinfo_t *);

#endif