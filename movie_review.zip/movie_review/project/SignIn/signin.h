#ifndef signin_H_
#define signin_H_

#include "../StructureResources.h"

void SignInPage(userinfo_t *);

#endif